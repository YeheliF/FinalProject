const express = require("express");
const app = express();
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const router = express.Router();
const MongoClient = require('mongodb').MongoClient
// const ejs = require("ejs");
// var engines = require('consolidate');
// const html = require("html");

app.use(bodyParser.urlencoded({extended: true}));
// app.set('view engine', 'ejs');
// app.engine('html', engines.mustache);
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');


// mongoose.connect("mongodb+srv://yeheli:yeheli123@flightperdiction.i2rhz.mongodb.net/firstDB", {useNewUrlParser: true},{ useUnifiedTopology: true})

//creat schema
const notesSchema = {
    flightNumber: String,
    Date: Date
}
var database


app.get("/", function(req, res){
    res.sendFile(__dirname + "/addFlight.html")
})

app.get("../addFlight.html", function(req, res){
    res.sendFile(__dirname + "/addFlight.html")
})

app.get("/login.html", function(req, res){
    // res.sendFile(__dirname + "/addFlight.html")
    res.sendFile(__dirname + "/login.html")
})

app.get("/myFlights.html", function(req, res){
    
    database.collection('notes').find({}).toArray((err, result)=>{
        if(err) throw err
        // res.send(result)
        res.render(__dirname + '/myflights.html', {items: result});
    })
    // var resultArray = [];
    // mongoose.connect("mongodb+srv://yeheli:yeheli123@flightperdiction.i2rhz.mongodb.net/firstDB",function(err, db){
        
    //     var cursor = db.collection('firstDB').find();
        
    //     cursor.forEach(function(doc, err){
    //         resultArray.push(doc);
    //     }, function(){
    //         db.close();
    //         res.render(__dirname + '/myflights.html', {items: resultArray});
    //     });
    // });
    
})





app.post("/", function(req, res){
    let newNote = new Note({
        flightNumber: req.body.flightNumber,
        Date: req.body.Date

    });
    newNote.save();
    console.log("added")
    res.redirect('/')
})

app.listen(3000, function(){
    console.log("server is running on 3000")
    MongoClient.connect("mongodb+srv://yeheli:yeheli123@flightperdiction.i2rhz.mongodb.net", {useNewUrlParser: true},(error,result)=>{
    if (error) throw error    
    database = result.db('firstDB')
    })
    const Note = mongoose.model("Note", notesSchema);
    console.log("connection works!")

})